"""
Analysis URL Configuration
"""
from django.urls import path

urlpatterns = [
    # Analysis endpoints will be added here
    # path('', AnalysisView.as_view(), name='analysis'),
]
