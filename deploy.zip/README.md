# MedScan Platform - Backend

Django REST API for MedScan medical image analysis platform.

## Tech Stack

- Django 5.0
- Django REST Framework
- PostgreSQL
- JWT Authentication
- TensorFlow/Keras

## Setup

### Prerequisites

- Python 3.11+
- PostgreSQL 16+
- Virtual environment

### Installation

```bash
# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Setup database
createdb medscan
cp .env.example .env
# Edit .env with your database credentials

# Run migrations
python manage.py migrate

# Create superuser
python manage.py createsuperuser

# Run development server
python manage.py runserver
```

The API will be available at [http://localhost:8000](http://localhost:8000)

## API Endpoints

### Authentication

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register/` | Register new user |
| POST | `/api/auth/login/` | Login and get JWT token |
| GET | `/api/auth/user/` | Get current user profile |
| PATCH | `/api/auth/user/` | Update user profile |

### Images

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/images/` | List all user's images |
| POST | `/api/images/` | Upload new image |
| GET | `/api/images/{id}/` | Get image details |
| DELETE | `/api/images/{id}/` | Delete image |

### Analysis

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/analysis/` | Start image analysis |
| GET | `/api/analysis/{id}/` | Get analysis results |

## Testing

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov

# Run specific test file
pytest apps/authentication/tests/test_views.py
```

## Code Quality

```bash
# Format code
black .
isort .

# Lint code
flake8 .
pylint **/*.py
```

## Project Structure

```
backend/
   apps/
      authentication/    # User authentication
      images/           # Image management
      analysis/         # ML analysis
   medscan/              # Project settings
   media/                # Uploaded files
   staticfiles/          # Static files
   requirements.txt
   manage.py
```

## Environment Variables

See `.env.example` for all required environment variables.

## Admin Panel

Access the Django admin at [http://localhost:8000/admin](http://localhost:8000/admin)

## API Documentation

Interactive API documentation available at:
- Swagger UI: [http://localhost:8000/api/docs/](http://localhost:8000/api/docs/)
- ReDoc: [http://localhost:8000/api/redoc/](http://localhost:8000/api/redoc/)
